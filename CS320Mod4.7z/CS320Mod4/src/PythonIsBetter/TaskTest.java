package PythonIsBetter;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest 
{
    @Test
    public boolean testIdTooLong() 
	{
        new Task("12345678901", "Name", "Description"); 
		if(taskId.length() > 10 || taskId == null)
		{
			System.out.println("ID too long or null.");
			return false;
		}
		else
		{
			return true;
		}

    }

    @Test
    public boolean testNameTooLong() 
	{
        new Task("1", "ChrisChrisChrisChrisC", "Description");
		if(name.length() > 20 || name == null)
		{
			System.out.println("Name too long or null.");
			return false;
		}
		else
		{
			return true;
		}

    }

    @Test
    public boolean testDescriptionTooLong() 
	{
        new Task("1", "Name", "ThisDescritpionShouldBeOverFiftyCharactersLong78901");
		if(description.length() > 50 || description == null)
		{
			System.out.println("Description too long or null.");
			return false;
		}
		else
		{
			return true;
		}
    }

    @Test
    public void testUpdateName() 
	{
        Task task = new Task("1", "Chris", "Description");
        task.setName("Not Chris");
        assertEquals("Not Chris", task.getName());
    }

    @Test
    public void testUpdateDescription() 
	{
        Task task = new Task("1", "Name", "Description");
        task.setDescription("NotDescription");
        assertEquals("NotDescription", task.getDescription());
    }

    @Test
    public boolean testUpdateNameTooLong() 
	{
        Task task = new Task("1", "ChrisChrisC", "Description");
		if(name.length() > 20 || name == null)
		{
			System.out.println("Name too long or null.");
			return false;
		}
		else
		{
			return true;
		}
    }

    @Test
    public boolean testUpdateDescriptionTooLong() 
	{
        Task task = new Task("1", "Chris", "Description");
		if(description.length() > 50 || description == null)
		{
			System.out.println("Description too long or null.");
			return false;
		}
		else
		{
			return true;
		}
	}
}