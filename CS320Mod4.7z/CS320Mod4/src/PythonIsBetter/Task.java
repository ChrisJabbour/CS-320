package PythonIsBetter;
public class Task 

{
    public final String taskId;  
    public String name;               
    public String description;        

    public Task(String taskId, String name, String description) 
	{
        checkValue(taskId, 10);
        checkValue(name, 20);
        checkValue(description, 50);
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() 
	{
        return taskId;
    }

    public String getName() 
	{
        return name;
    }

    public String getDescription() 
	{
        return description;
    }

    public void setName(String name) 
	{
        checkValue(name, 20);
        this.name = name;
    }

    public void setDescription(String description) 
	{
        checkValue(description, 50);
        this.description = description;
    }

	public void checkValue(String info, int stringThreshold)
	{
        if (info == null || info.length() > stringThreshold) 
		{
            System.out.println("Error! Either " + info + "is too long or null");
        }
    }
}