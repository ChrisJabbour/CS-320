package PythonIsBetter;
import java.util.ArrayList;
import java.util.List;

public class TaskService 
{
    public final List<Task> tasksList = new ArrayList<>();

    public Task findTask(String taskId) 
    {
        for (Task task : tasksList) 
        {
            if (task.getTaskId().equals(taskId)) 
            {
                return task;
            }
        }
        return null;
    }

    public void addTask(Task task) 
    {
        tasksList.add(task);
    }

    public void deleteTask(String taskId) 
    {
        Task task = findTask(taskId);
        tasksList.remove(task);
    }


    public void updateTaskName(String taskId, String newName) 
    {
        Task task = findTask(taskId);
        tasksList.setName(newName);
    }

    public void updateTaskDescription(String taskId, String newDescription) 
    {
        Task task = findTask(taskId);
        tasksList.setDescription(newDescription);
    }
}