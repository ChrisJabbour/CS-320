package PythonIsBetter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest 
{
    public TaskService service;

    @BeforeEach
    public void setup() 
    {
        service = new TaskService();
    }

    @Test
    public void testAddTask() 
    {
        Task task = new Task("1", "NewTask", "Description");
        service.addTask(task);
        assertEquals(1, service.getTasks().size());
    }

    @Test
    public void testDeleteTask() 
    {
        Task task = new Task("1", "Task", "Description");
        service.addTask(task);
        service.deleteTask("1");
        assertEquals(0, service.getTasks().size());
    }

    @Test
    public void testUpdateTaskName() 
    {
        Task task = new Task("1", "Old Name", "Description");
        service.addTask(task);
        service.updateTaskName("1", "NotName");
        assertEquals("NotName", service.getTasks().get(0).getName());
    }

    @Test
    public void testUpdateDescription() 
	{
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        service.updateTaskDescription("1", "NotDescription");
        assertEquals("NotDescription", service.getTasks().get(0).getDescription());
    }
}